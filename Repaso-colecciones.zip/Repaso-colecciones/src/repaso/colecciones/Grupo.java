package repaso.colecciones;

import java.util.ArrayList;

public class Grupo {
	private String nombre;
	private ArrayList<String> integrantes;
	
	public Grupo(String nomb){
		this.nombre=nomb;
		integrantes=new ArrayList<String>();
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int  getcanIntegrantes() {
		return integrantes.size();
	}
	
	public void agregarIntegrante(String nombreIntegrante){
		String integrante= buscarIntegrante(nombreIntegrante);
		if (integrante == null){
			integrantes.add(nombreIntegrante);
			System.out.println("Integreante Agregado");
		}
		else {
			System.out.println( "Integrante Existente");
			
		}
		
	}
	
	private int obtenerPosicionIntegrante(String nombreIntegrante){
		int i=0;
		String aux=null;
		int posicionEncontrada=0;
		while (i< this.integrantes.size()&& posicionEncontrada == 0 ){
			aux= integrantes.get(i);
			if(aux.equals(nombreIntegrante)){
				posicionEncontrada=i;
			}
				else i++;
		}
		if (posicionEncontrada==0){
			posicionEncontrada=-1;
			
		}
		return posicionEncontrada;	
	}

	public String obtenerIntegrante(int posicion){
		return integrantes.get(posicion-1);

	}
	
	public String buscarIntegrante(String nombre){
		int i=0;
		String aux=null;
		String integranteEncontrado=null;
		while (i< this.integrantes.size()&& integranteEncontrado ==null ){
			aux= integrantes.get(i);
			if(aux.equals(nombre)){
				integranteEncontrado=aux;

			}
				else i++;
		}
		return integranteEncontrado;
		
	}
	
	public String removerIntegrante(String nombreIntegrante){
		return integrantes.

	}
}
